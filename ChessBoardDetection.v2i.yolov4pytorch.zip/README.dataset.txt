# Chess Board Detection > 2024-12-26 6:54am
https://universe.roboflow.com/dataset-bbjj3/chess-board-detection-uuppk-44gm7

Provided by a Roboflow user
License: CC BY 4.0

